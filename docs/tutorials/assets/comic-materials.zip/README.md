# Comic Studio classroom materials

1. Open a new Studio project and delete the starter node.
2. In Resources, import `library.json`.
3. Set application input/output and the execution budget from `schemas/`.
4. Add and connect each node using `SETTINGS.md`; output schemas are separate JSON files for copying into the form.
5. Set your model connections and media service in the deployment profile.

The complete English and Chinese lesson: https://github.com/Toyhom/EvoSprig/blob/main/docs/tutorials/comic-studio.md

## 中文

新建工程并删除默认节点，在资源页导入 `library.json`。按照 `SETTINGS.md` 逐个添加节点和设置输入连接；`schemas/` 提供可粘贴的输出格式、应用输入和预算。模型和图像服务在部署配置中设置。
