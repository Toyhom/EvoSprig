# Comic Studio · field reference / 课堂字段表

Import `library.json` in Resources, then create the nodes below on the canvas. The library supplies tools and resources; this sheet gives their connections.

在资源页导入 `library.json`，再逐个创建下面的节点。库文件提供工具和资源，字段表用于设置连接。

## main

Order / 连线顺序: adapt → cast → panels → pages

### adapt · agent

| Setting / 设置 | Value / 值 |
| --- | --- |
| model | `"main"` |
| response_format | `"json"` |
| skills | `["continuity"]` |
| max_items | `32` |
| max_iterations | `1` |
| Prompt / 提示词资源 | `adapter` |
| Harness | `{"max_tool_rounds": 8, "tool_selection": "all", "tool_limit": 8, "parallel_tool_calls": false, "tool_errors": "raise", "output_errors": "feedback", "max_output_retries": 2, "max_output_tokens": 3200}` |
| Output schema / 输出格式 | [JSON](schemas/main-adapt-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `story` | `input.story` |

### cast · tool

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"assets"` |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-cast-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `characters` | `nodes.adapt.output.characters` |
| `style` | `nodes.adapt.output.style` |

### pages · tool

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"layout"` |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-pages-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `panels` | `nodes.panels.output.items` |
| `title` | `nodes.adapt.output.title` |

### panels · map

| Setting / 设置 | Value / 值 |
| --- | --- |
| response_format | `"text"` |
| max_items | `8` |
| max_iterations | `1` |
| items | `{"ref": "nodes.adapt.output.panels", "optional": false, "default": null}` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `catalog` | `nodes.cast.output` |
| `style` | `nodes.adapt.output.style` |

### Workflow outputs / 工作流输出

| Field / 字段 | Source / 来源 |
| --- | --- |
| `catalog` | `nodes.cast.output` |
| `chapter` | `nodes.pages.output` |
| `panels` | `nodes.panels.output.items` |
| `plan` | `nodes.adapt.output` |

## main/panels

Order / 连线顺序: context → takes → letter

### context · code

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"python"` |
| code | `"frame_context"` |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-context-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `catalog` | `input.context.catalog` |
| `index` | `input.index` |
| `panel` | `input.item` |
| `style` | `input.context.style` |

### letter · code

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"python"` |
| code | `"panel"` |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-letter-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `image` | `nodes.takes.output.image` |
| `panel` | `input.item` |

### takes · loop

| Setting / 设置 | Value / 值 |
| --- | --- |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `3` |
| until | `{"left": {"ref": "input.accepted", "optional": false, "default": null}, "op": "truthy", "right": null}` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-takes-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `attempt` | `nodes.context.output.attempt` |
| `feedback` | `nodes.context.output.feedback` |
| `options` | `nodes.context.output.options` |
| `panel` | `nodes.context.output.panel` |
| `reference_ids` | `nodes.context.output.reference_ids` |
| `references` | `nodes.context.output.references` |
| `seed` | `nodes.context.output.seed` |
| `style` | `nodes.context.output.style` |

### Workflow outputs / 工作流输出

| Field / 字段 | Source / 来源 |
| --- | --- |
| `caption` | `nodes.letter.output.caption` |
| `dialogue` | `nodes.letter.output.dialogue` |
| `image` | `nodes.letter.output.image` |

## main/panels/takes

Order / 连线顺序: direct → draw → preview → review → remember

### direct · agent

| Setting / 设置 | Value / 值 |
| --- | --- |
| model | `"main"` |
| response_format | `"json"` |
| max_items | `32` |
| max_iterations | `1` |
| Prompt / 提示词资源 | `frame_director` |
| Harness | `{"max_tool_rounds": 8, "tool_selection": "all", "tool_limit": 8, "parallel_tool_calls": false, "tool_errors": "raise", "output_errors": "feedback", "max_output_retries": 1, "max_output_tokens": 1800}` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-takes-direct-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `context` | `input` |

### draw · tool

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"image"` |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-takes-draw-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `options` | `input.options` |
| `prompt` | `nodes.direct.output.prompt` |
| `references` | `input.references` |

### preview · tool

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"preview"` |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-takes-preview-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `asset` | `nodes.draw.output` |

### remember · code

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"python"` |
| code | `"frame_carry"` |
| response_format | `"text"` |
| max_items | `32` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-takes-remember-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `image` | `nodes.draw.output` |
| `review` | `nodes.review.output` |
| `state` | `input` |

### review · agent

| Setting / 设置 | Value / 值 |
| --- | --- |
| model | `"vision"` |
| response_format | `"json"` |
| image_inputs | `["images"]` |
| max_items | `32` |
| max_iterations | `1` |
| Prompt / 提示词资源 | `frame_review` |
| Harness | `{"max_tool_rounds": 8, "tool_selection": "all", "tool_limit": 8, "parallel_tool_calls": false, "tool_errors": "raise", "output_errors": "feedback", "max_output_retries": 1, "max_output_tokens": 1200}` |
| Output schema / 输出格式 | [JSON](schemas/main-panels-takes-review-output.json) |

| Input field / 输入字段 | Source / 来源 |
| --- | --- |
| `images` | `nodes.preview.output.images` |
| `panel` | `input.panel` |

### Workflow outputs / 工作流输出

| Field / 字段 | Source / 来源 |
| --- | --- |
| `accepted` | `nodes.remember.output.accepted` |
| `attempt` | `nodes.remember.output.attempt` |
| `feedback` | `nodes.remember.output.feedback` |
| `image` | `nodes.remember.output.image` |
| `options` | `nodes.remember.output.options` |
| `panel` | `nodes.remember.output.panel` |
| `reference_ids` | `nodes.remember.output.reference_ids` |
| `references` | `nodes.remember.output.references` |
| `seed` | `nodes.remember.output.seed` |
| `style` | `nodes.remember.output.style` |

