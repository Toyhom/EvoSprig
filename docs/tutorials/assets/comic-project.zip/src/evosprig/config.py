"""Deployment bindings are separate from behavior versions."""

import os
from copy import deepcopy
from functools import lru_cache
from pathlib import Path

import yaml

from evosprig.core.spec import AgentSpec
from evosprig.plugins.mock import MockProvider


@lru_cache(maxsize=8)
def _parse_profile(content):
    return yaml.safe_load(content)


def read_profile(path):
    """Reuse YAML parsing while observing file changes and isolating callers."""
    return deepcopy(_parse_profile(Path(path).read_text())) if path else {}


def make_models(spec: AgentSpec, profile: str | Path | None = None, mock: bool = False) -> dict:
    bindings = {item.binding for item in spec.models.values()}
    if mock:
        return {name: MockProvider() for name in bindings}
    if not bindings:
        return {}
    from evosprig.plugins.openai_compatible import Connection, OpenAICompatibleProvider

    if profile:
        raw = read_profile(profile)
        if (
            not isinstance(raw, dict)
            or set(raw) - {"models", "tools", "evaluation", "services"}
            or "models" not in raw
        ):
            raise ValueError("deployment profile needs models and optional tools, evaluation or services")
        profiles = raw["models"]
        for name in bindings & profiles.keys():
            service = profiles[name].get("local_service")
            if service and service not in raw.get("services", {}):
                raise ValueError(f"model {name}: unknown local service {service}")
    else:
        profiles = {
            name: {
                "base_url": os.environ.get("EVOSPRIG_BASE_URL", "https://api.deepseek.com"),
                "model": os.environ.get("EVOSPRIG_MODEL", "deepseek-flash"),
                "api_key_env": "DEEPSEEK_API_KEY",
                "options": {"thinking": {"type": "disabled"}},
            }
            for name in bindings
        }
    missing = bindings - profiles.keys()
    if missing:
        raise ValueError(f"missing profile bindings: {sorted(missing)}")
    return {
        name: OpenAICompatibleProvider(Connection.model_validate(profiles[name]))
        for name in bindings
    }


def restore_models(metadata: dict) -> dict:
    """Restore recorded connections; credentials are resolved from the current process environment."""
    models = {}
    for name, binding in metadata.items():
        if binding["adapter"] == "MockProvider":
            models[name] = MockProvider()
        elif binding["adapter"] == "OpenAICompatibleProvider" and "connection" in binding:
            from evosprig.plugins.openai_compatible import Connection, OpenAICompatibleProvider

            models[name] = OpenAICompatibleProvider(
                Connection.model_validate(binding["connection"])
            )
        else:
            raise ValueError("recorded model adapter is unavailable")
    return models


def make_tools(workspace, scope, *, profile=None, bindings=None):
    from evosprig.plugins.builtin_tools import builtin_registry
    from evosprig.plugins.memory_tools import register_memory_tools
    from evosprig.plugins.sqlite_memory import SQLiteMemory

    registry = register_memory_tools(
        builtin_registry(), SQLiteMemory(Path(workspace) / "memory.sqlite"), scope
    )
    from evosprig.plugins.workspace_tools import WorkspaceStore, register_workspace_tools

    register_workspace_tools(registry, WorkspaceStore(Path(workspace) / "documents.sqlite"), scope)
    from evosprig.plugins.python_tool import python_tool

    registry.register(python_tool())
    from evosprig.plugins.message_tools import MessageStore, register_message_tools

    register_message_tools(registry, MessageStore(Path(workspace) / "messages.sqlite"), scope)
    if bindings is None:
        raw = read_profile(profile)
        bindings = raw.get("tools", {})
    for name, raw in bindings.items():
        if raw.get("kind") == "artifact":
            from evosprig.plugins.artifact_tools import ArtifactToolConfig, artifact_tool

            config = ArtifactToolConfig.model_validate(raw)
            tool = artifact_tool(config, workspace, scope)
        elif raw.get("kind") == "http":
            from evosprig.plugins.http_tools import HTTPToolConfig, http_tool

            config = HTTPToolConfig.model_validate(raw)
            tool = http_tool(config)
        elif raw.get("kind") == "external_http":
            from evosprig.plugins.external_http import ExternalHTTPConfig, external_http_tool

            config = ExternalHTTPConfig.model_validate(raw)
            tool = external_http_tool(config)
        elif raw.get("kind") == "mcp":
            from evosprig.plugins.mcp_tools import MCPToolConfig, mcp_tool

            config = MCPToolConfig.model_validate(raw)
            tool = mcp_tool(config)
        elif raw.get("kind") == "repository":
            from evosprig.plugins.repository_tools import RepositoryToolConfig, repository_tool

            config = RepositoryToolConfig.model_validate(raw)
            tool = repository_tool(config, Path(workspace) / "repositories", scope)
        elif raw.get("kind") == "sqlite":
            from evosprig.plugins.sqlite_tools import SQLiteToolConfig, sqlite_tool

            config = SQLiteToolConfig.model_validate(raw)
            tool = sqlite_tool(config)
        elif raw.get("kind") == "comfy_collect":
            from evosprig.plugins.comfy_tools import ComfyCollectConfig, comfy_collect_tool

            config = ComfyCollectConfig.model_validate(raw)
            tool = comfy_collect_tool(config)
        elif raw.get("kind") == "comfy_node":
            from evosprig.plugins.comfy_tools import ComfyNodeConfig, comfy_node_tool

            config = ComfyNodeConfig.model_validate(raw)
            tool = comfy_node_tool(config)
        elif raw.get("kind") in {"comfy_recipe", "comfy_recipe_info"}:
            from evosprig.plugins.comfy_tools import ComfyRecipeConfig, comfy_recipe_tool

            config = ComfyRecipeConfig.model_validate(raw)
            tool = comfy_recipe_tool(config)
        elif raw.get("kind") == "comfy_job":
            from evosprig.plugins.comfy_tools import ComfyJobConfig, comfy_job_tool

            config = ComfyJobConfig.model_validate(raw)
            tool = comfy_job_tool(config, Path(workspace) / "comfy.sqlite", scope)
        else:
            raise ValueError("unknown tool binding kind")
        if name != config.name:
            raise ValueError("tool binding key must match its name")
        registry.register(tool)
        registry.bindings[name] = config.model_dump(mode="json")
    return registry


def load_principals(path):
    from evosprig.server.auth import Principal

    raw = yaml.safe_load(Path(path).read_text())
    if not isinstance(raw, list) or not raw:
        raise ValueError("identity configuration must be a nonempty list")
    principals = {}
    for item in raw:
        if not isinstance(item, dict) or set(item) != {"user", "tenant", "token_env"}:
            raise ValueError("each principal needs user, tenant and token_env")
        token = os.environ.get(item["token_env"])
        if not token or token in principals:
            raise ValueError("principal token is empty or duplicated")
        principals[token] = Principal(item["user"], item["tenant"])
    return principals
