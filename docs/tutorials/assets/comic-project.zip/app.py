import argparse
import asyncio
import json
from pathlib import Path

from evosprig.config import make_models, make_tools, restore_models
from evosprig.core.journal import Scope
from evosprig.core.spec import load_spec
from evosprig.core.version import compile_agent
from evosprig.core.runtime import Runtime
from evosprig.plugins.sqlite_journal import SQLiteJournal

parser = argparse.ArgumentParser(description="Run the exported EvoSprig agent")
inputs = parser.add_mutually_exclusive_group()
inputs.add_argument("--input", help="JSON input object")
inputs.add_argument("--input-file", type=Path, help="JSON task input file")
parser.add_argument("--mock", action="store_true")
parser.add_argument("--profile")
parser.add_argument("--workspace", type=Path)
parser.add_argument("--resume", help="Run ID to resume")
parser.add_argument("--path", help="Waiting input path")
parser.add_argument("--response", help="JSON human response")
parser.add_argument("--allow-writes", action="store_true")
parser.add_argument("--documents", type=Path, help="Load text documents into this application's workspace")
args = parser.parse_args()
root = Path(__file__).resolve().parent
spec = load_spec(root / "agent.yaml")
version = compile_agent(spec, root)
expected = json.loads((root / "agent.lock.json").read_text())
if version.lock != expected:
    raise SystemExit("Project changed: rebuild the export to update agent.lock.json")
workspace = args.workspace or root / ".evosprig"
if args.documents:
    if args.input or args.input_file or args.resume or args.path or args.response:
        parser.error("load documents separately from running or resuming the agent")
    from evosprig.data_cli import add_documents
    print(json.dumps(add_documents(args.documents, workspace, spec.id), indent=2))
    raise SystemExit(0)
journal = SQLiteJournal(workspace / "runs.sqlite")
if args.profile and not args.mock:
    from evosprig.local_services import prepare_services
    prepare_services(args.profile)
if args.resume:
    record = journal.get(args.resume)
    if record["version"]["version_id"] != version.version_id:
        raise SystemExit("Run belongs to a different exported version")
    if bool(args.path) != bool(args.response):
        parser.error("--path and --response must be supplied together")
    if args.response:
        journal.respond(args.resume, args.path, json.loads(args.response))
    runtime = Runtime(restore_models(record["metadata"]["models"]), make_tools(workspace, Scope(spec.id), bindings=record["metadata"].get("tools", {})), journal=journal,
                      allow_writes=record["metadata"]["allow_writes"])
    result = asyncio.run(runtime.resume(args.resume))
else:
    if args.input is None and args.input_file is None:
        parser.error("provide --input for a new run")
    bindings = None if args.profile else json.loads((root / "tool-bindings.json").read_text())
    runtime = Runtime(make_models(spec, args.profile, args.mock), make_tools(workspace, Scope(spec.id), profile=args.profile, bindings=bindings), journal=journal,
                      allow_writes=args.allow_writes)
    result = asyncio.run(runtime.run(version, json.loads(args.input_file.read_text() if args.input_file else args.input)))
print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
raise SystemExit(1 if result.status in {"failed", "canceled"} else 0)
