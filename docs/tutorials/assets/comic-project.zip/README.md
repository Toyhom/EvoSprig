# Exported EvoSprig application

Create a Python 3.12+ environment, then run:

```bash
python -m pip install -r requirements.lock
python -m pip install --no-deps .
python app.py --mock --input '<JSON matching agent.yaml input_schema>'
```

For live calls, copy deployment.example.yaml to deployment.yaml, set each connection's provider URL, model ID and API-key environment variable, then pass --profile deployment.yaml and omit --mock. Vision bindings need a model that accepts images. Set environment variables in your terminal; .env.example is a template. Runtime sources are bundled; installation and execution use no Studio or control plane. Review export-report.json for required external services. The selected version is fixed in agent.lock.json.

For document applications, load your own text collection with `python app.py --documents ./notes --workspace ./workspace`. Use the same `--workspace` for subsequent runs or the HTTP service. Exports do not contain your database or memory records.
