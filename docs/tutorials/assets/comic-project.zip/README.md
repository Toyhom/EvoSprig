# Exported EvoSprig application

Create a Python 3.12+ environment, then run:

```bash
python -m pip install -r requirements.lock
python -m pip install --no-deps .
python app.py --mock --input '<JSON matching agent.yaml input_schema>'
```

For live calls, copy deployment.example.yaml to deployment.yaml, set each connection's provider URL, model ID and API-key environment variable, then pass --profile deployment.yaml and omit --mock. Vision bindings need a model that accepts images. Set environment variables in your terminal; .env.example is a template. Runtime sources are bundled; installation and execution use no Studio or control plane. Review export-report.json for required external services. The selected version is fixed in agent.lock.json.

For document applications, load your own text collection with `python app.py --documents ./notes --workspace ./workspace`. Use the same `--workspace` for subsequent runs or the HTTP service. Exports do not contain your database or memory records.

## HTTP service

Set `EVOSPRIG_SERVICE_TOKEN` to a secret, then run `python serve.py --mock`.
The service listens on loopback port 8080. Use `--profile deployment.yaml` for live
models, `--workspace PATH` for persistent SQLite, and `--concurrency N` for its bounded
worker pool. Writes require both the spec policy and operator `--allow-writes`.

Send `Authorization: Bearer <token>` to `POST /runs` with `{"input": {...}}`.
Poll `GET /runs/{run_id}`, read `/runs/{run_id}/events` (SSE, Last-Event-ID),
submit `POST /runs/{run_id}/input` with `{"path": "...", "response": {...}}`, or
`POST /runs/{run_id}/cancel`. Restarting the service resumes queued/checkpointed runs.
This is a single-agent, single-trust-domain service. Use a separate workspace per
exported version. Put TLS at a reverse proxy for remote access; browser origins are
rejected. `/health` is public and contains no run data.

## Container target

When a Dockerfile is present: `docker build -t my-agent .`, then
`docker run --rm -p 127.0.0.1:8080:8080 -e EVOSPRIG_SERVICE_TOKEN -e DEEPSEEK_API_KEY
-v evosprig-state:/state my-agent --host 0.0.0.0 --workspace /state --mock`.
Remove `--mock` for live calls. The image runs as UID 10001. Credentials, runtime
history and model weights are not build inputs. The Python base image is tag-pinned;
pin its digest in your deployment registry for immutable rebuilds.

## Comic Studio browser application

The complete setup and two-story walkthrough: https://github.com/Toyhom/EvoSprig/blob/main/docs/tutorials/comic-studio.md

With the exported HTTP service running on 18770, start `python comic_app.py --workspace runtime --port 18771` in another terminal with the same EVOSPRIG_SERVICE_TOKEN. Open http://127.0.0.1:18771/ (Chinese: /?lang=zh). Submit another story to reuse this application.
