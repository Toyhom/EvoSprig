import argparse
import os
from pathlib import Path
import uvicorn
from evosprig.server.standalone import create_service

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--workspace", type=Path, default=Path(".evosprig"))
    parser.add_argument("--profile", type=Path)
    parser.add_argument("--mock", action="store_true")
    parser.add_argument("--allow-writes", action="store_true")
    parser.add_argument("--concurrency", type=int, default=4)
    args = parser.parse_args()
    app = create_service(Path(__file__).resolve().parent, args.workspace,
                         token=os.environ.get("EVOSPRIG_SERVICE_TOKEN"), profile=args.profile,
                         mock=args.mock, allow_writes=args.allow_writes, concurrency=args.concurrency)
    uvicorn.run(app, host=args.host, port=args.port, access_log=False)
