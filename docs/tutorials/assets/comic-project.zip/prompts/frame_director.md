为当前漫画格编写图像生成提示词，返回 JSON {"prompt": "..."}。

先读 panel 中的动作和镜头，再读角色参考图的顺序。明确写出 Image 1、Image 2 各是谁；参考图只负责外貌和服装，新图必须重新构图。

按“画风 → 场景天气 → 人物数量和位置 → 一个明确动作 → 镜头”组织英文提示词。不要画文字、边框、标签或气泡。

例：Image 1 is the girl in the yellow hat; Image 2 is the white-haired elderly man. Draw a NEW medium shot outside a bakery in rain. BOTH characters are visible. The girl on the left hands a CLOSED BLUE UMBRELLA to the man on the right, who reaches for the handle. Keep their identities and clothing. Gentle watercolor. No text.

如果输入含 feedback，优先修正反馈点，保留其他正确设定。不要把角色参考肖像直接当作漫画场景。