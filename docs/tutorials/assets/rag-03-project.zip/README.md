# Exported EvoSprig application

Create a Python 3.12+ environment, then run:

```bash
python -m pip install -r requirements.lock
python -m pip install --no-deps .
python app.py --mock --input '<JSON matching agent.yaml input_schema>'
```

For live calls, copy deployment.example.yaml to deployment.yaml, set each connection's provider URL, model ID and API-key environment variable, then pass --profile deployment.yaml and omit --mock. Vision bindings need a model that accepts images. Set environment variables in your terminal; .env.example is a template. Runtime sources are bundled; installation and execution use no Studio or control plane. Review export-report.json for required external services. The selected version is fixed in agent.lock.json.

For document applications, load files with `python app.py --documents ./notes --profile deployment.yaml --workspace ./workspace`. Install `requirements-documents.lock` for PDF/image support and Tesseract plus the desired language packs for OCR. Configure file limits, chunking, OCR and customer uploads in deployment.yaml. Use the same `--workspace` for subsequent runs or the HTTP service. Exports do not contain your database or memory records.

## HTTP service

Set `EVOSPRIG_SERVICE_TOKEN` to a secret, then run `python serve.py --mock`.
The service listens on loopback port 8080. Use `--profile deployment.yaml` for live
models, `--workspace PATH` for persistent SQLite, and `--concurrency N` for its bounded
worker pool. Writes require both the spec policy and operator `--allow-writes`.

Send `Authorization: Bearer <token>` to `POST /runs` with `{"input": {...}}`.
Poll `GET /runs/{run_id}`, read `/runs/{run_id}/events` (SSE, Last-Event-ID),
submit `POST /runs/{run_id}/input` with `{"path": "...", "response": {...}}`, or
`POST /runs/{run_id}/cancel`. Restarting the service resumes queued/checkpointed runs.
This is a single-agent, single-trust-domain service. Use a separate workspace per
exported version. Put TLS at a reverse proxy for remote access; browser origins are
rejected. `/health` is public and contains no run data.

## Customer knowledge library

Enable `documents.customer_uploads: true` in deployment.yaml to let your application
manage its knowledge library. Authenticate with the service token from your backend.
Upload raw file bytes to `POST /documents/upload?filename=manual.pdf`, poll the returned
job at `GET /documents/jobs/{id}`, list `GET /documents`, search
`GET /documents/search?query=...`, or delete `DELETE /documents/{id}`.
Uploading the same source replaces it atomically after successful parsing.
The deployed graph stays unchanged and the next run uses the updated library.
Keep service credentials in your application backend; do not embed them in browser code.

## Container target

When a Dockerfile is present: `docker build -t my-agent .`, then
`docker run --rm -p 127.0.0.1:8080:8080 -e EVOSPRIG_SERVICE_TOKEN -e DEEPSEEK_API_KEY
-v evosprig-state:/state my-agent --host 0.0.0.0 --workspace /state --mock`.
Remove `--mock` for live calls. The image runs as UID 10001. Credentials, runtime
history and model weights are not build inputs. The Python base image is tag-pinned;
pin its digest in your deployment registry for immutable rebuilds.
