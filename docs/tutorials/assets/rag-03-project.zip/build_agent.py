from evosprig.sdk import Builder

builder = Builder(
    'rag-classroom',
    {'additionalProperties': False,
 'properties': {'question': {'type': 'string'}},
 'required': ['question'],
 'type': 'object'},
    {'additionalProperties': False,
 'properties': {'text': {'type': 'string'}},
 'required': ['text'],
 'type': 'object'},
    spec_version='0.3',
)
builder.model('main', 'main', ['text', 'tool_calling', 'structured_output'])
builder.tool('retrieve_many', 'documents.retrieve', '1')
builder.tool('search', 'documents.search', '1')
builder.resource('agent', 'prompts/agent.md', 'prompt')
builder.resource('answer', 'prompts/answer.md', 'prompt')
builder.resource('check_citations', 'code/check_citations.py', 'code')
builder.resource('rewrite', 'prompts/rewrite.md', 'prompt')
builder.node('answer', 'model', entry=False, **{'branches': {},
 'image_inputs': [],
 'inputs': {'citations': {'optional': False,
                          'ref': 'nodes.retrieve.output.citations'},
            'question': {'optional': False, 'ref': 'input.question'}},
 'instructions': {'resource': 'answer'},
 'join': 'all',
 'max_items': 32,
 'max_iterations': 1,
 'max_output_retries': 2,
 'model': 'main',
 'output_errors': 'feedback',
 'output_schema': {'additionalProperties': False,
                   'properties': {'text': {'type': 'string'}},
                   'required': ['text'],
                   'type': 'object'},
 'output_validator': 'check_citations',
 'parallel_tool_calls': False,
 'response_format': 'text',
 'skills': [],
 'tool_errors': 'raise',
 'tool_limit': 8,
 'tool_selection': 'all',
 'tools': []})
builder.node('retrieve', 'tool', entry=True, **{'branches': {},
 'image_inputs': [],
 'inputs': {'limit': {'value': 5},
            'query': {'optional': False, 'ref': 'input.question'}},
 'instructions': '',
 'join': 'all',
 'max_items': 32,
 'max_iterations': 1,
 'max_output_retries': 1,
 'output_errors': 'raise',
 'output_schema': {'type': 'object'},
 'parallel_tool_calls': False,
 'response_format': 'text',
 'skills': [],
 'tool': 'search',
 'tool_errors': 'raise',
 'tool_limit': 8,
 'tool_selection': 'all',
 'tools': []})
builder.edge('retrieve', 'answer', when=None)
builder.output(**{'text': {'default': None,
          'optional': False,
          'ref': 'nodes.answer.output.text'}})
builder.execution(**{'max_steps': 32, 'max_model_calls': 10, 'max_total_tokens': 16000, 'max_output_tokens': 1500, 'image_token_reserve': 4096, 'timeout_seconds': 180.0, 'max_parallel_nodes': 1, 'max_parallel_tools': 1, 'allow_side_effects': False, 'pure_checkpoint_interval': 1})
spec = builder.build_spec()
