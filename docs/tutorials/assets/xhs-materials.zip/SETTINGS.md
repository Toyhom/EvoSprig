# Xiaohongshu Studio · field reference / 课堂字段表

Import `library.json` in Resources; create the nodes below. Set **main** as Application default model.
在资源页导入 `library.json`，将应用默认模型设为 **main**，再逐个添加节点。

## main

Order / 连线顺序: prepare → editing → format → brief

### prepare · code

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"python"` |
| code | `"prepare"` |
| response_format | `"text"` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-prepare-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `request` | `input` |

### editing · loop

| Setting / 设置 | Value / 值 |
| --- | --- |
| response_format | `"text"` |
| max_iterations | `3` |
| until | `{"left": {"ref": "input.accepted", "optional": false, "default": null}, "op": "truthy", "right": null}` |
| Output schema / 输出格式 | [JSON](schemas/main-editing-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `brief` | `nodes.brief.output` |
| `changes` | `[]` (fixed / 固定值) |
| `feedback` | `[]` (fixed / 固定值) |
| `previous` | `{}` (fixed / 固定值) |
| `request` | `nodes.prepare.output` |
| `rounds` | `0` (fixed / 固定值) |

### format · code

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"python"` |
| code | `"format"` |
| response_format | `"text"` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-format-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `state` | `nodes.editing.output` |

### brief · agent

| Setting / 设置 | Value / 值 |
| --- | --- |
| response_format | `"json"` |
| skills | `["source_fidelity", "examples"]` |
| temperature | `0.2` |
| max_iterations | `1` |
| Prompt / 提示词 | `brief` |
| Harness | `{"max_tool_rounds": 1, "tool_selection": "all", "tool_limit": 8, "parallel_tool_calls": false, "tool_errors": "raise", "output_errors": "feedback", "max_output_retries": 1, "max_output_tokens": 2400}` |
| Output schema / 输出格式 | [JSON](schemas/main-brief-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `request` | `nodes.prepare.output` |

### Workflow outputs / 工作流输出

| Field / 字段 | Source / 来源 |
| --- | --- |
| `changes` | `nodes.format.output.changes` |
| `feedback` | `nodes.format.output.feedback` |
| `post` | `nodes.format.output.post` |
| `ready` | `nodes.format.output.ready` |
| `rounds` | `nodes.format.output.rounds` |
| `text` | `nodes.format.output.text` |

## main/editing

Order / 连线顺序: draft → review → check → remember

### draft · agent

| Setting / 设置 | Value / 值 |
| --- | --- |
| response_format | `"json"` |
| skills | `["voice", "source_fidelity", "examples"]` |
| temperature | `0.6` |
| max_iterations | `1` |
| Prompt / 提示词 | `draft` |
| Harness | `{"max_tool_rounds": 1, "tool_selection": "all", "tool_limit": 8, "parallel_tool_calls": false, "tool_errors": "raise", "output_errors": "feedback", "max_output_retries": 1, "max_output_tokens": 2400}` |
| Output schema / 输出格式 | [JSON](schemas/main-editing-draft-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `brief` | `input.brief` |
| `feedback` | `input.feedback` |
| `previous` | `input.previous` |
| `request` | `input.request` |

### review · agent

| Setting / 设置 | Value / 值 |
| --- | --- |
| response_format | `"json"` |
| skills | `["voice", "source_fidelity"]` |
| temperature | `0.2` |
| max_iterations | `1` |
| Prompt / 提示词 | `review` |
| Harness | `{"max_tool_rounds": 1, "tool_selection": "all", "tool_limit": 8, "parallel_tool_calls": false, "tool_errors": "raise", "output_errors": "feedback", "max_output_retries": 1, "max_output_tokens": 2400}` |
| Output schema / 输出格式 | [JSON](schemas/main-editing-review-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `brief` | `input.brief` |
| `checks` | `nodes.check.output` |
| `post` | `nodes.draft.output` |
| `request` | `input.request` |

### check · code

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"python"` |
| code | `"check"` |
| response_format | `"text"` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-editing-check-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `post` | `nodes.draft.output` |
| `request` | `input.request` |

### remember · code

| Setting / 设置 | Value / 值 |
| --- | --- |
| tool | `"python"` |
| code | `"remember"` |
| response_format | `"text"` |
| max_iterations | `1` |
| Output schema / 输出格式 | [JSON](schemas/main-editing-remember-output.json) |

| Input / 输入 | Source / 来源 |
| --- | --- |
| `checks` | `nodes.check.output` |
| `post` | `nodes.draft.output` |
| `review` | `nodes.review.output` |
| `state` | `input` |

### Workflow outputs / 工作流输出

| Field / 字段 | Source / 来源 |
| --- | --- |
| `accepted` | `nodes.remember.output.accepted` |
| `brief` | `nodes.remember.output.brief` |
| `changes` | `nodes.remember.output.changes` |
| `feedback` | `nodes.remember.output.feedback` |
| `previous` | `nodes.remember.output.previous` |
| `request` | `nodes.remember.output.request` |
| `rounds` | `nodes.remember.output.rounds` |

