# Xiaohongshu Studio classroom materials

Create an empty Studio project. Import `library.json` in Resources, then create and connect the eight nodes using `SETTINGS.md`. Copy the application and node schemas from `schemas/`. Configure the model connection in your deployment profile.

新建空白项目，在资源页导入 `library.json`，按照 `SETTINGS.md` 创建并连接八个节点。`schemas/` 提供应用输入、输出、预算及各节点输出格式。模型连接在部署配置中填写。

[English lesson](https://github.com/Toyhom/EvoSprig/blob/main/docs/tutorials/xiaohongshu-studio.md) · [中文教程](https://github.com/Toyhom/EvoSprig/blob/main/docs/zh-CN/tutorials/xiaohongshu-studio.md)
